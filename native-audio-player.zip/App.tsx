
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, 
  Music, Search, Plus, ListMusic, 
  Repeat, Shuffle, Heart, MoreHorizontal, FolderSearch,
  ChevronDown, AlertCircle, PlayCircle, Settings, SlidersHorizontal,
  Trash2, Info, Moon, Sun, CheckCircle2, RotateCcw, X
} from 'lucide-react';
import { Track } from './types';

const PRESETS = {
  Flat: [0, 0, 0, 0, 0],
  Rock: [4, 2, -2, 2, 4],
  Pop: [-1, 2, 4, 2, -1],
  Bass: [6, 4, 0, 0, 0],
  Vocal: [-2, -2, 3, 4, 1]
};

const App: React.FC = () => {
  // Estados Principales
  const [tracks, setTracks] = useState<Track[]>([]);
  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Estados de UI
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isEqOpen, setIsEqOpen] = useState(false);

  // Estados de Ecualizador
  const [eqGains, setEqGains] = useState<number[]>(PRESETS.Flat);
  const [activePreset, setActivePreset] = useState<string>('Flat');

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  
  // Web Audio API refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const filtersRef = useRef<BiquadFilterNode[]>([]);

  const currentTrack = currentTrackIndex >= 0 ? tracks[currentTrackIndex] : null;

  // --- Inicialización del Audio Context y EQ ---
  useEffect(() => {
    if (audioRef.current && !audioCtxRef.current) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioCtxRef.current = ctx;

      const source = ctx.createMediaElementSource(audioRef.current);

      const freqs = [60, 230, 910, 4000, 14000];
      const filters = freqs.map((freq, i) => {
        const filter = ctx.createBiquadFilter();
        filter.type = i === 0 ? 'lowshelf' : i === freqs.length - 1 ? 'highshelf' : 'peaking';
        filter.frequency.value = freq;
        filter.gain.value = eqGains[i];
        return filter;
      });

      source.connect(filters[0]);
      for (let i = 0; i < filters.length - 1; i++) {
        filters[i].connect(filters[i + 1]);
      }
      filters[filters.length - 1].connect(ctx.destination);
      filtersRef.current = filters;
    }
  }, [audioRef.current]);

  // Actualizar ganancias de filtros cuando cambie el estado del EQ
  useEffect(() => {
    filtersRef.current.forEach((filter, i) => {
      filter.gain.value = eqGains[i];
    });
  }, [eqGains]);

  const updateEq = (index: number, value: number) => {
    const newGains = [...eqGains];
    newGains[index] = value;
    setEqGains(newGains);
    setActivePreset('Custom');
    if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
  };

  const applyPreset = (name: keyof typeof PRESETS) => {
    setEqGains(PRESETS[name]);
    setActivePreset(name);
  };

  // --- Lógica de Reproducción ---
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  useEffect(() => {
    if (audioRef.current && currentTrack) {
      if (isPlaying) {
        audioRef.current.play().catch(() => setIsPlaying(false));
        if (audioCtxRef.current?.state === 'suspended') audioCtxRef.current.resume();
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentTrack]);

  const startAutoScan = () => {
    if (folderInputRef.current) folderInputRef.current.click();
  };

  const handleFolderSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setIsScanning(true);
    const mp3Tracks: Track[] = files
      .filter(f => f.name.toLowerCase().endsWith('.mp3'))
      .map(file => ({
        id: Math.random().toString(36).substring(2, 11) + Date.now(),
        name: file.name.replace(/\.[^/.]+$/, ""),
        artist: 'Archivo Local',
        album: 'Memoria del Dispositivo',
        duration: 0,
        url: URL.createObjectURL(file),
        file: file,
        addedAt: Date.now()
      }));

    setTracks(mp3Tracks);
    setHasPermission(true);
    setTimeout(() => setIsScanning(false), 1200);
  };

  const playTrack = (index: number) => {
    setCurrentTrackIndex(index);
    setIsPlaying(true);
    setProgress(0);
  };

  const nextTrack = useCallback(() => {
    if (tracks.length === 0) return;
    setCurrentTrackIndex((prev) => (prev + 1) % tracks.length);
  }, [tracks.length]);

  const prevTrack = () => {
    if (tracks.length === 0) return;
    setCurrentTrackIndex((prev) => (prev - 1 + tracks.length) % tracks.length);
  };

  const clearLibrary = () => {
    setTracks([]);
    setHasPermission(false);
    setIsSettingsOpen(false);
    setCurrentTrackIndex(-1);
    setIsPlaying(false);
  };

  const formatTime = (time: number) => {
    if (isNaN(time) || time === Infinity) return "0:00";
    const mins = Math.floor(time / 60);
    const secs = Math.floor(time % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredTracks = useMemo(() => 
    tracks.filter(t => t.name.toLowerCase().includes(searchQuery.toLowerCase())),
    [tracks, searchQuery]
  );

  // Pantalla de Permisos
  if (!hasPermission && !isScanning) {
    return (
      <div className="h-screen flex items-center justify-center bg-black p-8 font-sans">
        <div className="max-w-sm w-full bg-[#0a0a0a] rounded-[60px] p-12 flex flex-col items-center text-center shadow-2xl border border-white/5">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-[35px] flex items-center justify-center mb-10 shadow-2xl shadow-blue-500/20 animate-pulse">
            <Music size={48} className="text-white" />
          </div>
          <h1 className="text-4xl font-black mb-4 tracking-tighter">Native Music</h1>
          <p className="text-gray-500 mb-12 text-lg leading-relaxed">
            Escaneo automático de archivos MP3. Selecciona tu carpeta de música para comenzar.
          </p>
          <button 
            onClick={startAutoScan}
            className="w-full py-5 bg-white text-black font-black rounded-3xl text-xl hover:bg-gray-200 transition-all active:scale-95 shadow-xl"
          >
            Escaneo Inteligente
          </button>
          <input type="file" ref={folderInputRef} className="hidden" webkitdirectory="" directory="" multiple onChange={handleFolderSelect} />
        </div>
      </div>
    );
  }

  // Pantalla de Escaneo
  if (isScanning) {
    return (
      <div className="h-screen flex flex-col items-center justify-center bg-black">
        <div className="relative w-40 h-40 mb-10">
          <div className="absolute inset-0 border-4 border-blue-500/20 rounded-full"></div>
          <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <Music size={48} className="text-blue-500 animate-pulse" />
          </div>
        </div>
        <h2 className="text-3xl font-black tracking-tighter mb-2">Analizando Memoria</h2>
        <p className="text-gray-500 font-bold uppercase tracking-widest text-[10px]">Identificando archivos de audio...</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-black text-white overflow-hidden select-none font-sans relative">
      <audio 
        ref={audioRef} 
        src={currentTrack?.url} 
        onTimeUpdate={() => setProgress(audioRef.current?.currentTime || 0)}
        onLoadedMetadata={() => setDuration(audioRef.current?.duration || 0)}
        onEnded={nextTrack}
      />

      {/* Main UI */}
      <main className={`flex-1 flex flex-col transition-all duration-500 ${isPlayerOpen ? 'scale-90 opacity-0 pointer-events-none' : 'scale-100 opacity-100'}`}>
        <header className="px-8 pt-16 pb-6 flex flex-col gap-6 sticky top-0 bg-black/80 backdrop-blur-3xl z-20 border-b border-white/5">
          <div className="flex items-center justify-between">
            <h1 className="text-4xl font-black tracking-tighter bg-gradient-to-r from-white to-gray-500 bg-clip-text text-transparent">Biblioteca</h1>
            <div className="flex gap-2">
              <button onClick={() => setIsEqOpen(true)} className="p-3 bg-[#111] border border-white/5 rounded-full active:scale-90 transition-all">
                <SlidersHorizontal size={22} className="text-blue-500" />
              </button>
              <button onClick={() => setIsSettingsOpen(true)} className="p-3 bg-[#111] border border-white/5 rounded-full active:scale-90 transition-all">
                <Settings size={22} className="text-gray-400" />
              </button>
            </div>
          </div>
          
          <div className="relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-500" size={20} />
            <input 
              type="text"
              placeholder="¿Qué quieres escuchar?"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#111] border border-white/5 rounded-2xl py-4 pl-14 pr-6 outline-none text-lg placeholder:text-gray-600 focus:ring-2 ring-blue-500/20 transition-all"
            />
          </div>
        </header>

        <div className="flex-1 overflow-y-auto px-6 pb-40 pt-4">
          {filteredTracks.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center opacity-30">
               <Music size={64} className="mb-4" />
               <p className="font-bold">Sin resultados</p>
            </div>
          ) : (
            <div className="space-y-1">
              {filteredTracks.map((track) => {
                const globalIdx = tracks.findIndex(t => t.id === track.id);
                const isCurrent = globalIdx === currentTrackIndex;
                return (
                  <div 
                    key={track.id}
                    onClick={() => playTrack(globalIdx)}
                    className={`flex items-center gap-4 p-4 rounded-[28px] cursor-pointer active:scale-[0.98] transition-all ${isCurrent ? 'bg-white/5 border border-white/5 shadow-lg' : 'hover:bg-white/5 border border-transparent'}`}
                  >
                    <div className="w-14 h-14 bg-[#0a0a0a] rounded-2xl flex items-center justify-center flex-shrink-0 relative overflow-hidden border border-white/5">
                      {isCurrent && isPlaying ? (
                         <div className="flex gap-1 items-end h-6">
                           <div className="w-1 bg-blue-500 animate-[bounce_0.6s_infinite_0.1s]"></div>
                           <div className="w-1 bg-blue-500 animate-[bounce_0.6s_infinite_0.3s]"></div>
                           <div className="w-1 bg-blue-500 animate-[bounce_0.6s_infinite_0.2s]"></div>
                         </div>
                      ) : (
                        <Music size={24} className={isCurrent ? 'text-blue-500' : 'text-gray-800'} />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className={`text-lg font-bold truncate ${isCurrent ? 'text-blue-500' : 'text-gray-100'}`}>
                        {track.name}
                      </h4>
                      <p className="text-[10px] text-gray-600 font-black uppercase tracking-widest truncate">MPEG Audio Layer III</p>
                    </div>
                    <button className="text-gray-800 p-2"><MoreHorizontal size={24} /></button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* Mini Player */}
      {currentTrack && !isPlayerOpen && (
        <div 
          onClick={() => setIsPlayerOpen(true)}
          className="fixed bottom-6 left-6 right-6 h-22 bg-[#0a0a0a]/90 backdrop-blur-3xl border border-white/10 rounded-[35px] flex items-center px-4 gap-4 shadow-[0_20px_50px_rgba(0,0,0,0.5)] z-40 active:scale-95 transition-transform animate-in slide-in-from-bottom duration-500"
        >
          <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-indigo-800 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-500/10">
            <Music size={24} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h5 className="text-base font-black truncate">{currentTrack.name}</h5>
            <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse"></span>
                <p className="text-[9px] text-gray-500 font-black uppercase tracking-[0.2em]">En línea</p>
            </div>
          </div>
          <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
             <button onClick={() => setIsPlaying(!isPlaying)} className="w-12 h-12 flex items-center justify-center bg-white rounded-full text-black shadow-lg">
               {isPlaying ? <Pause size={24} className="fill-current" /> : <Play size={24} className="fill-current ml-1" />}
             </button>
          </div>
        </div>
      )}

      {/* REPRODUCTOR FULL (Modal) */}
      {isPlayerOpen && currentTrack && (
        <div className="fixed inset-0 z-50 bg-[#000] flex flex-col animate-in slide-in-from-bottom duration-500">
          <div className="absolute inset-0 bg-gradient-to-b from-blue-900/10 via-black to-black pointer-events-none" />
          
          <div className="p-10 pt-16 flex items-center justify-between z-10">
            <button onClick={() => setIsPlayerOpen(false)} className="p-4 bg-white/5 rounded-full active:scale-90 transition-all border border-white/5">
              <ChevronDown size={32} />
            </button>
            <div className="text-center">
              <p className="text-[10px] uppercase tracking-[0.4em] text-gray-600 font-black mb-1">Local Playback</p>
              <p className="text-sm font-bold text-white">Sonido Premium</p>
            </div>
            <button onClick={() => setIsEqOpen(true)} className="p-4 bg-white/5 rounded-full active:scale-90 transition-all border border-white/5">
              <SlidersHorizontal size={28} className="text-blue-500" />
            </button>
          </div>

          <div className="flex-1 flex items-center justify-center px-12 z-10">
            <div className="w-full aspect-square max-w-[340px] bg-[#0a0a0a] rounded-[70px] shadow-[0_60px_100px_-20px_rgba(0,0,0,1)] flex items-center justify-center relative overflow-hidden border border-white/5 group">
              <Music size={120} strokeWidth={1} className="text-[#111] group-hover:scale-110 transition-transform duration-[5s] ease-out" />
              {isPlaying && (
                <div className="absolute bottom-14 flex gap-2 h-12 items-end">
                   <div className="w-2 bg-blue-600 animate-[bounce_0.6s_infinite_0.1s] rounded-full"></div>
                   <div className="w-2 bg-blue-500 animate-[bounce_0.6s_infinite_0.3s] rounded-full"></div>
                   <div className="w-2 bg-indigo-500 animate-[bounce_0.6s_infinite_0.2s] rounded-full"></div>
                   <div className="w-2 bg-blue-400 animate-[bounce_0.6s_infinite_0.4s] rounded-full"></div>
                </div>
              )}
            </div>
          </div>

          <div className="px-12 pb-24 z-10">
            <div className="mb-12">
              <h2 className="text-4xl font-black tracking-tighter mb-2 line-clamp-2 leading-[1.1]">{currentTrack.name}</h2>
              <p className="text-xl text-gray-600 font-bold">Archivo MP3 Nativo</p>
            </div>

            {/* Progreso */}
            <div className="mb-12 space-y-4">
              <div className="relative h-2 flex items-center group">
                <input 
                  type="range"
                  min="0"
                  max={duration || 0}
                  value={progress}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    if (audioRef.current) audioRef.current.currentTime = val;
                    setProgress(val);
                  }}
                  className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full transition-all"
                />
                <div 
                  className="absolute left-0 top-1/2 -translate-y-1/2 h-1.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full pointer-events-none"
                  style={{ width: `${(progress / (duration || 1)) * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-xs font-black font-mono text-gray-600 tracking-tighter">
                <span>{formatTime(progress)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Controles Reales */}
            <div className="flex items-center justify-between px-2 mb-12">
              <button className="text-gray-700 hover:text-white transition-colors"><Shuffle size={24} /></button>
              <div className="flex items-center gap-10">
                <button onClick={prevTrack} className="active:scale-90 transition-transform text-white">
                  <SkipBack size={48} className="fill-current" />
                </button>
                <button 
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-24 h-24 bg-white text-black rounded-full flex items-center justify-center shadow-[0_20px_40px_rgba(255,255,255,0.1)] active:scale-90 transition-all"
                >
                  {isPlaying ? <Pause size={48} className="fill-current" /> : <Play size={48} className="fill-current ml-2" />}
                </button>
                <button onClick={nextTrack} className="active:scale-90 transition-transform text-white">
                  <SkipForward size={48} className="fill-current" />
                </button>
              </div>
              <button className="text-gray-700 hover:text-white transition-colors"><Repeat size={24} /></button>
            </div>

            {/* Volumen */}
            <div className="flex items-center gap-6 text-gray-500 bg-[#0a0a0a] p-6 rounded-[35px] border border-white/5">
              <VolumeX size={20} />
              <input 
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="flex-1 h-1 bg-white/10 rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full"
              />
              <Volume2 size={20} />
            </div>
          </div>
        </div>
      )}

      {/* ECUALIZADOR (Panel lateral/Modal) */}
      {isEqOpen && (
        <div className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-3xl flex flex-col animate-in fade-in duration-300">
           <div className="p-10 pt-16 flex items-center justify-between">
             <button onClick={() => setIsEqOpen(false)} className="p-4 bg-white/5 rounded-full border border-white/5">
                <X size={28} />
             </button>
             <h3 className="text-2xl font-black">Ecualizador</h3>
             <button onClick={() => applyPreset('Flat')} className="p-4 bg-white/5 rounded-full border border-white/5 text-blue-500">
                <RotateCcw size={28} />
             </button>
           </div>

           <div className="flex-1 flex flex-col justify-center px-10">
              <div className="flex justify-between items-end h-[300px] mb-16 gap-4">
                {eqGains.map((gain, i) => (
                  <div key={i} className="flex flex-col items-center flex-1 h-full gap-4">
                    <div className="relative h-full w-2 bg-white/5 rounded-full flex items-center justify-center">
                       <input 
                         type="range"
                         min="-12"
                         max="12"
                         step="1"
                         value={gain}
                         onChange={(e) => updateEq(i, parseInt(e.target.value))}
                         className="absolute inset-0 w-[300px] -rotate-90 appearance-none bg-transparent cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-8 [&::-webkit-slider-thumb]:h-8 [&::-webkit-slider-thumb]:bg-blue-600 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:border-4 [&::-webkit-slider-thumb]:border-white"
                         style={{ transform: 'rotate(-90deg) translate(0px, 0px)' }}
                       />
                    </div>
                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">
                      {['60Hz', '230Hz', '910Hz', '4kHz', '14kHz'][i]}
                    </span>
                    <span className="text-xs font-black text-blue-500">{gain > 0 ? `+${gain}` : gain}dB</span>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-3 gap-3">
                 {Object.keys(PRESETS).map((p) => (
                   <button 
                     key={p}
                     onClick={() => applyPreset(p as any)}
                     className={`py-4 rounded-2xl font-black text-sm border transition-all ${activePreset === p ? 'bg-blue-600 border-blue-400 text-white' : 'bg-white/5 border-white/5 text-gray-400'}`}
                   >
                     {p}
                   </button>
                 ))}
              </div>
           </div>
           <div className="p-10 text-center">
              <p className="text-[10px] text-gray-700 font-bold uppercase tracking-[0.3em]">Audio Engine v1.2</p>
           </div>
        </div>
      )}

      {/* AJUSTES (Panel lateral/Modal) */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-[60] bg-[#0a0a0a] flex flex-col animate-in slide-in-from-right duration-500">
           <header className="p-10 pt-16 flex items-center gap-6 border-b border-white/5">
             <button onClick={() => setIsSettingsOpen(false)} className="p-4 bg-white/5 rounded-full">
                <ChevronDown size={28} className="rotate-90" />
             </button>
             <h3 className="text-3xl font-black">Ajustes</h3>
           </header>

           <div className="flex-1 overflow-y-auto p-8 space-y-10">
              <section>
                <h4 className="text-xs font-black text-gray-600 uppercase tracking-[0.3em] mb-6">Biblioteca</h4>
                <div className="space-y-2">
                   <div className="bg-white/5 p-6 rounded-[30px] flex items-center justify-between border border-white/5">
                      <div className="flex items-center gap-4">
                        <ListMusic className="text-blue-500" />
                        <div>
                          <p className="font-bold">Total de Canciones</p>
                          <p className="text-xs text-gray-500">{tracks.length} archivos .mp3</p>
                        </div>
                      </div>
                      <CheckCircle2 className="text-green-500" size={20} />
                   </div>
                   <button 
                    onClick={clearLibrary}
                    className="w-full bg-red-500/10 p-6 rounded-[30px] flex items-center gap-4 text-red-500 border border-red-500/10 active:bg-red-500/20 transition-all"
                   >
                      <Trash2 />
                      <span className="font-bold">Borrar Biblioteca</span>
                   </button>
                </div>
              </section>

              <section>
                <h4 className="text-xs font-black text-gray-600 uppercase tracking-[0.3em] mb-6">Apariencia</h4>
                <div className="bg-white/5 p-6 rounded-[30px] flex items-center justify-between border border-white/5">
                    <div className="flex items-center gap-4">
                      <Moon className="text-indigo-400" />
                      <p className="font-bold">Modo Nocturno</p>
                    </div>
                    <div className="w-12 h-6 bg-blue-600 rounded-full flex items-center px-1">
                       <div className="w-4 h-4 bg-white rounded-full ml-auto shadow-sm"></div>
                    </div>
                </div>
              </section>

              <section>
                <h4 className="text-xs font-black text-gray-600 uppercase tracking-[0.3em] mb-6">Acerca de</h4>
                <div className="bg-white/5 p-8 rounded-[35px] border border-white/5 space-y-4">
                   <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                         <Music size={20} />
                      </div>
                      <p className="text-xl font-black italic">NativePlayer</p>
                   </div>
                   <p className="text-sm text-gray-400 leading-relaxed">
                     Reproductor de música local de alto rendimiento. Optimizado para dispositivos móviles y procesamiento de audio en tiempo real.
                   </p>
                   <div className="pt-4 flex gap-4 text-[10px] font-black text-gray-600 uppercase">
                      <span>Versión 2.0.4</span>
                      <span>•</span>
                      <span>Build 2024</span>
                   </div>
                </div>
              </section>
           </div>
           
           <div className="p-10 border-t border-white/5 flex items-center justify-center gap-2 opacity-30">
              <AlertCircle size={14} />
              <span className="text-[10px] font-bold uppercase tracking-widest">Sin conexión necesaria</span>
           </div>
        </div>
      )}
    </div>
  );
};

export default App;
